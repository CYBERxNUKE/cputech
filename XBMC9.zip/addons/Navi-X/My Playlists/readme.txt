Store your downloaded PLX files in this folder. You can browse
these playlists from the "My Playlists" section in Navi-X.

Enjoy.